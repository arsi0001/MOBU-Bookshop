//
//  Book.swift
//  BookShop
//
//  Created by Arthur on 14/01/16.
//  Copyright © 2016 Arthur. All rights reserved.
//

import Foundation

struct Book {
    var dateiName: String
    var autor: String
    var titel: String
    var preis: String
    var beschreibung: String
    var merkmale: String
    var kundenrez: String
}