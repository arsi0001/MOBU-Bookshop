//
//  PersonCell.swift
//  BookShop
//
//  Created by Arthur on 14/01/16.
//  Copyright © 2016 Arthur. All rights reserved.
//

import UIKit

class BookCell: UICollectionViewCell {
    
    @IBOutlet weak var bookImageView: UIImageView!
    @IBOutlet weak var bookLabel: UILabel!
}
