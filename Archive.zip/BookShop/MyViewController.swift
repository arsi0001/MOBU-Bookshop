//
//  MyViewController.swift
//  BookShop
//
//  Created by Arthur on 05/01/16.
//  Copyright © 2016 Arthur. All rights reserved.
//

import UIKit

class MyViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate {

    @IBOutlet weak var menuButton: UIBarButtonItem!
    @IBOutlet weak var collectionView: UICollectionView!
    
    var books: [Book]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.demotData()
        
        let image = UIImage(named: "onlyLogo")
        navigationItem.titleView = UIImageView(image: image)
        

        if self.revealViewController() != nil{
            menuButton.target = self.revealViewController()
            menuButton.action = "revealToggle:"
            self.view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
        }
    }
    
    func demotData(){
        let book1: Book = Book(
            dateiName: "Buch 1",
            autor: "Roman Hanser",
            titel: "ECO Nullnummer",
            preis: "14,99",
            beschreibung: "Mailand, 6. Juni 1992, nachts. Bei dem Journalisten Colonna ist eingebrochen worden. Die Diskette mit brisanten Informationen hat man nicht gefunden, Colonna sieht jetzt sein eigenes Leben bedroht.",
            merkmale: "Verlag: Hanser,Best.Nr. des Verlages: 505/24939, Seitenzahl: 240, 2015, Ausstattung/Bilder: 2015.240 S. 211 mm Deutsch",
            kundenrez: "Super Buch, sehr spannend!")
        
        let book2: Book = Book(
            dateiName: "Buch 2",
            autor: "Ellen Berg",
            titel: "Mach mir den Garten, Liebling",
            preis: "12,99",
            beschreibung: "Mailand, 6. Juni 1992, nachts. Bei dem Journalisten Colonna ist eingebrochen worden. Die Diskette mit brisanten Informationen hat man nicht gefunden, Colonna sieht jetzt sein eigenes Leben bedroht.",
            merkmale: "Verlag: Hanser,Best.Nr. des Verlages: 505/24939, Seitenzahl: 240, 2015, Ausstattung/Bilder: 2015.240 S. 211 mm Deutsch",
            kundenrez: "Super Buch, sehr spannend!")
        
        let book3: Book = Book(
            dateiName: "Buch 3",
            autor: "Lucinda Riley",
            titel: "Die Sturmschwester",
            preis: "19,99",
            beschreibung: "Mailand, 6. Juni 1992, nachts. Bei dem Journalisten Colonna ist eingebrochen worden. Die Diskette mit brisanten Informationen hat man nicht gefunden, Colonna sieht jetzt sein eigenes Leben bedroht.",
            merkmale: "Verlag: Hanser,Best.Nr. des Verlages: 505/24939, Seitenzahl: 240, 2015, Ausstattung/Bilder: 2015.240 S. 211 mm Deutsch",
            kundenrez: "Super Buch, sehr spannend!")
        
        let book4: Book = Book(
            dateiName: "Buch 4",
            autor: "Michael Lüders",
            titel: "Wer den Wind sät",
            preis: "9,45",
            beschreibung: "Mailand, 6. Juni 1992, nachts. Bei dem Journalisten Colonna ist eingebrochen worden. Die Diskette mit brisanten Informationen hat man nicht gefunden, Colonna sieht jetzt sein eigenes Leben bedroht.",
            merkmale: "Verlag: Hanser,Best.Nr. des Verlages: 505/24939, Seitenzahl: 240, 2015, Ausstattung/Bilder: 2015.240 S. 211 mm Deutsch", kundenrez: "Super Buch, sehr spannend!")
        let book5: Book = Book(
            dateiName: "Buch 5",
            autor: "Sebastian Fitzek",
            titel: "Passagier 23",
            preis: "14,99",
            beschreibung: "Mailand, 6. Juni 1992, nachts. Bei dem Journalisten Colonna ist eingebrochen worden. Die Diskette mit brisanten Informationen hat man nicht gefunden, Colonna sieht jetzt sein eigenes Leben bedroht.",
            merkmale: "Verlag: Hanser,Best.Nr. des Verlages: 505/24939, Seitenzahl: 240, 2015, Ausstattung/Bilder: 2015.240 S. 211 mm Deutsch",
            kundenrez: "Super Buch, sehr spannend!")
        let book6: Book = Book(
            dateiName: "Buch 6",
            autor: "Nele Neuhaus",
            titel: "Die Lebenden und die Toten",
            preis: "25.00",
            beschreibung: "Mailand, 6. Juni 1992, nachts. Bei dem Journalisten Colonna ist eingebrochen worden. Die Diskette mit brisanten Informationen hat man nicht gefunden, Colonna sieht jetzt sein eigenes Leben bedroht.",
            merkmale: "Verlag: Hanser,Best.Nr. des Verlages: 505/24939, Seitenzahl: 240, 2015, Ausstattung/Bilder: 2015.240 S. 211 mm Deutsch",
            kundenrez: "Super Buch, sehr spannend!")
        let book7: Book = Book(
            dateiName: "Buch 7",
            autor: "Jojo Moyes",
            titel: "Ein ganz neues Leben",
            preis: "7,80", beschreibung: "Mailand, 6. Juni 1992, nachts. Bei dem Journalisten Colonna ist eingebrochen worden. Die Diskette mit brisanten Informationen hat man nicht gefunden, Colonna sieht jetzt sein eigenes Leben bedroht.",
            merkmale: "Verlag: Hanser,Best.Nr. des Verlages: 505/24939, Seitenzahl: 240, 2015, Ausstattung/Bilder: 2015.240 S. 211 mm Deutsch",
            kundenrez: "Super Buch, sehr spannend!")
        
        let book8: Book = Book(
            dateiName: "Buch 8",
            autor: "Kristina Henn",
            titel: "Ostwind - Aufbruch nach Ora",
            preis: "14,99",
            beschreibung: "Mailand, 6. Juni 1992, nachts. Bei dem Journalisten Colonna ist eingebrochen worden. Die Diskette mit brisanten Informationen hat man nicht gefunden, Colonna sieht jetzt sein eigenes Leben bedroht.",
            merkmale: "Verlag: Hanser,Best.Nr. des Verlages: 505/24939, Seitenzahl: 240, 2015, Ausstattung/Bilder: 2015.240 S. 211 mm Deutsch",
            kundenrez: "Super Buch, sehr spannend!")
        
        let book9: Book = Book(
            dateiName: "Buch 9",
            autor: "Jeff Kinney",
            titel: "Gregs Tagebuch - So ein Mist!",
            preis: "12.50",
            beschreibung: "Mailand, 6. Juni 1992, nachts. Bei dem Journalisten Colonna ist eingebrochen worden. Die Diskette mit brisanten Informationen hat man nicht gefunden, Colonna sieht jetzt sein eigenes Leben bedroht.",
            merkmale: "Verlag: Hanser,Best.Nr. des Verlages: 505/24939, Seitenzahl: 240, 2015, Ausstattung/Bilder: 2015.240 S. 211 mm Deutsch",
            kundenrez: "Super Buch, sehr spannend!")
        
        let book10: Book = Book(
            dateiName: "Buch 10",
            autor: "Werner Kurz",
            titel: "Guinness World Records 2016",
            preis: "15,00",
            beschreibung: "Mailand, 6. Juni 1992, nachts. Bei dem Journalisten Colonna ist eingebrochen worden. Die Diskette mit brisanten Informationen hat man nicht gefunden, Colonna sieht jetzt sein eigenes Leben bedroht.",
            merkmale: "Verlag: Hanser,Best.Nr. des Verlages: 505/24939, Seitenzahl: 240, 2015, Ausstattung/Bilder: 2015.240 S. 211 mm Deutsch",
            kundenrez: "Super Buch, sehr spannend!")
        
        let book11: Book = Book(
            dateiName: "Buch 11",
            autor: "Jochen Schweizer",
            titel: "Der perfekte Augenblick",
            preis: "30,00",
            beschreibung: "Mailand, 6. Juni 1992, nachts. Bei dem Journalisten Colonna ist eingebrochen worden. Die Diskette mit brisanten Informationen hat man nicht gefunden, Colonna sieht jetzt sein eigenes Leben bedroht.",
            merkmale: "Verlag: Hanser,Best.Nr. des Verlages: 505/24939, Seitenzahl: 240, 2015, Ausstattung/Bilder: 2015.240 S. 211 mm Deutsch",
            kundenrez: "Super Buch, sehr spannend!")
        
        let book12: Book = Book(
            dateiName: "Buch 12",
            autor: "Erin Hunter",
            titel: "Warrior Cats",
            preis: "3,99",
            beschreibung: "Mailand, 6. Juni 1992, nachts. Bei dem Journalisten Colonna ist eingebrochen worden. Die Diskette mit brisanten Informationen hat man nicht gefunden, Colonna sieht jetzt sein eigenes Leben bedroht.",
            merkmale: "Verlag: Hanser,Best.Nr. des Verlages: 505/24939, Seitenzahl: 240, 2015, Ausstattung/Bilder: 2015.240 S. 211 mm Deutsch",
            kundenrez: "Super Buch, sehr spannend!")
        
        let book13: Book = Book(
            dateiName: "Buch 13",
            autor: "Rebecca Gable",
            titel: "Der Palast der Meere",
            preis: "14,99", beschreibung: "Mailand, 6. Juni 1992, nachts. Bei dem Journalisten Colonna ist eingebrochen worden. Die Diskette mit brisanten Informationen hat man nicht gefunden, Colonna sieht jetzt sein eigenes Leben bedroht.",
            merkmale: "Verlag: Hanser,Best.Nr. des Verlages: 505/24939, Seitenzahl: 240, 2015, Ausstattung/Bilder: 2015.240 S. 211 mm Deutsch",
            kundenrez: "Super Buch, sehr spannend!")
        
        let book14: Book = Book(
            dateiName: "Buch 14",
            autor: "Micaela Jary",
            titel: "Wie ein fernes Lied",
            preis: "14,99",
            beschreibung: "Mailand, 6. Juni 1992, nachts. Bei dem Journalisten Colonna ist eingebrochen worden. Die Diskette mit brisanten Informationen hat man nicht gefunden, Colonna sieht jetzt sein eigenes Leben bedroht.",
            merkmale: "Verlag: Hanser,Best.Nr. des Verlages: 505/24939, Seitenzahl: 240, 2015, Ausstattung/Bilder: 2015.240 S. 211 mm Deutsch",
            kundenrez: "Super Buch, sehr spannend!")
        
        let book15: Book = Book(
            dateiName: "Buch 15",
            autor: "Patricia Schröder",
            titel: "Tilla, Zwieback und die verzwickte Zoorettung",
            preis: "14,99",
            beschreibung: "Mailand, 6. Juni 1992, nachts. Bei dem Journalisten Colonna ist eingebrochen worden. Die Diskette mit brisanten Informationen hat man nicht gefunden, Colonna sieht jetzt sein eigenes Leben bedroht.",
            merkmale: "Verlag: Hanser,Best.Nr. des Verlages: 505/24939, Seitenzahl: 240, 2015, Ausstattung/Bilder: 2015.240 S. 211 mm Deutsch",
            kundenrez: "Super Buch, sehr spannend!")
        
        self.books = [book1, book2, book3, book4, book5, book6, book7, book8, book9, book10, book11, book12, book13, book14, book15]
    }
    
    func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if books != nil{
            return books!.count
        }
        else {
            return 0
        }
    }
    
    
    func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell{
        let cell: BookCell = collectionView.dequeueReusableCellWithReuseIdentifier("BookCell", forIndexPath: indexPath) as! BookCell
        let currentBook: Book = self.books![indexPath.row]
        cell.bookImageView.image = UIImage(named: currentBook.dateiName)
        cell.bookLabel.text = currentBook.titel
        
        
        return cell
    }
    
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        super.prepareForSegue(segue, sender: sender)
        
       /* if segue.identifier == "toDetailView" {
            let detailVC: DetailViewController? = segue.destinationViewController as? DetailViewController
            
            if detailVC != nil {
                let item: Book = self.books![self.collectionView.indexPathsForSelectedItems()![0].row]
                
                detailVC?.title = item.titel
                detailVC?.imageName = item.dateiName
            }
        }*/
        
        if segue.identifier == "toArtikelView"{
            let detailVC: PROBETableViewController? = segue.destinationViewController as? PROBETableViewController
            
            if detailVC != nil {
                let item: Book = self.books![self.collectionView.indexPathsForSelectedItems()![0].row]
                
                detailVC?.imageName = item.dateiName
                detailVC?.titelName = item.titel
                detailVC?.autorName = item.autor
                detailVC?.preis = item.preis
                detailVC?.beschreibung = item.beschreibung
                detailVC?.merkmale = item.merkmale
                detailVC?.kundenrez = item.kundenrez
            }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

    }}
