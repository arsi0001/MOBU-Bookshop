//
//  People.swift
//  BookShop
//
//  Created by Arthur on 16/01/16.
//  Copyright © 2016 Arthur. All rights reserved.
//

import Foundation

struct People {
    var name: String
    var portraitImageName: String
    var bookImageName: String
}